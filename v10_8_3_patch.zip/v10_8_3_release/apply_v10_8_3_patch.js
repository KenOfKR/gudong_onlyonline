#!/usr/bin/env node
'use strict';

// v10.8.3 四模組局部補丁安裝器。只覆寫四個指定模組並新增一個回歸測試。
// 不執行 Git、commit、push 或部署。
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(process.argv[2] || process.cwd());
const payloadRoot = path.join(__dirname, 'payload');
const files = [
  { rel: 'js/bot/mind.js', sha256: 'b688d3a654eee9f084e61666b84f430b842be982c0e6507b5cd1f328aa565fcb', markers: ['const confirmedFlip = i.flipped === true;', 'function playerById(room, id)'], newMarker: 'const confirmedFlip = i.flipped === true;' },
  { rel: 'js/core/claims.js', sha256: 'c8886d7f53f7930b48d2412213c7db7697b3e958b83957eb1313d7b4f8e63c53', markers: ['voteCommitment: parsed.voteCommitment || null', 'function parseRecord(sp, room, roundArg)'], newMarker: 'voteCommitment: parsed.voteCommitment || null' },
  { rel: 'js/bot/speech.js', sha256: '845c3ffb2811b03f9752089ee00954e5e9685283ac928a06c13f8a2eeaab50fd', markers: ["const totals = vr.totals && typeof vr.totals === 'object' ? vr.totals : null;", 'function history(room)'], newMarker: "const totals = vr.totals && typeof vr.totals === 'object' ? vr.totals : null;" },
  { rel: 'js/bot/strategy.js', sha256: '6431d2649d4ae65403a0a44e9a4c5f02a90513dc9036a2ee6821b833fe438ad2', markers: ['const promisedBeast = ownSpeechData.voteCommitment || null;', 'function enforcePublicTargetAnchor(ballot, target, maxSpend)'], newMarker: 'const promisedBeast = ownSpeechData.voteCommitment || null;' },
  { rel: 'tests/v10-8-3-reasoning-smoke.js', sha256: 'dbd1c7ba44db776abb365dfb36148f9000c36f36857de4431a58f9425c3df4dd', markers: ['v10.8.3 推理回歸通過'] }
];

function fail(message) {
  console.error('[停止] ' + message);
  process.exit(1);
}
function sha256(text) {
  return crypto.createHash('sha256').update(String(text).replace(/\r\n/g, '\n'), 'utf8').digest('hex');
}
function readUtf8(file) {
  return fs.readFileSync(file, 'utf8');
}

if (!fs.existsSync(path.join(root, 'js/config.js'))) {
  fail('找不到 js/config.js。請把專案根目錄路徑傳給安裝器。');
}
const config = readUtf8(path.join(root, 'js/config.js'));
const versionMatch = config.match(/\bVERSION\s*:\s*['"]([^'"]+)['"]/);
if (!versionMatch || versionMatch[1] !== '10.8.2') {
  fail('只接受 CONFIG.VERSION = 10.8.2 的專案；目前偵測到 ' + (versionMatch ? versionMatch[1] : '未知版本') + '。未寫入任何檔案。');
}

const prepared = [];
for (const item of files) {
  const payloadPath = path.join(payloadRoot, item.rel);
  const targetPath = path.join(root, item.rel);
  if (!fs.existsSync(payloadPath)) fail('補丁封裝缺少檔案：' + item.rel);
  if (item.rel !== 'tests/v10-8-3-reasoning-smoke.js' && !fs.existsSync(targetPath)) {
    fail('專案缺少目標模組：' + item.rel);
  }
  const content = readUtf8(payloadPath);
  if (sha256(content) !== item.sha256) fail('補丁檔案雜湊不符，可能已損毀：' + item.rel);
  for (const marker of item.markers) {
    if (!content.includes(marker)) fail('補丁檔案缺少必要標記：' + item.rel + ' / ' + marker);
  }
  prepared.push({ ...item, targetPath, content });
}

const allTargetsMatch = prepared.every(item =>
  fs.existsSync(item.targetPath) && sha256(readUtf8(item.targetPath)) === item.sha256
);
if (allTargetsMatch) {
  console.log('v10.8.3 已完整安裝，所有目標檔案雜湊相符；未重複寫入。');
  process.exit(0);
}

// 若已有部分 v10.8.3 標記但檔案不完整，停止而不是覆蓋不明狀態。
const sourceItems = prepared.filter(item => item.rel !== 'tests/v10-8-3-reasoning-smoke.js');
const detectedPartial = sourceItems.some(item => {
  const current = readUtf8(item.targetPath);
  return current.includes(item.newMarker);
});
if (detectedPartial) {
  fail('偵測到部分 v10.8.3 內容或混合版本，但不是完整相符狀態。請先還原四個模組，再重新安裝。');
}

const testItem = prepared.find(item => item.rel === 'tests/v10-8-3-reasoning-smoke.js');
if (fs.existsSync(testItem.targetPath) && sha256(readUtf8(testItem.targetPath)) !== testItem.sha256) {
  fail('測試檔已存在且內容不同，拒絕覆蓋：' + testItem.rel);
}

const stamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14) + '-' + process.pid;
const backups = [];
const writes = [];
const testExistedBefore = fs.existsSync(testItem.targetPath);
for (const item of prepared) {
  if (fs.existsSync(item.targetPath)) {
    const backup = item.targetPath + '.pre-v10.8.3-' + stamp + '.bak';
    backups.push({ targetPath: item.targetPath, backup, content: readUtf8(item.targetPath) });
  }
  const old = fs.existsSync(item.targetPath) ? readUtf8(item.targetPath) : '';
  const newline = old.includes('\r\n') ? '\r\n' : '\n';
  writes.push({ targetPath: item.targetPath, content: newline === '\n' ? item.content : item.content.replace(/\n/g, '\r\n') });
}

try {
  for (const item of backups) fs.writeFileSync(item.backup, item.content, 'utf8');
  for (const item of writes) {
    fs.mkdirSync(path.dirname(item.targetPath), { recursive: true });
    fs.writeFileSync(item.targetPath, item.content, 'utf8');
  }
} catch (error) {
  for (const item of backups) {
    try { fs.writeFileSync(item.targetPath, item.content, 'utf8'); } catch (_) {}
    try { fs.unlinkSync(item.backup); } catch (_) {}
  }
  if (!testExistedBefore) {
    try { fs.unlinkSync(testItem.targetPath); } catch (_) {}
  }
  fail('寫入失敗，已嘗試還原備份：' + (error.stack || error.message || error));
}

console.log('v10.8.3 局部補丁安裝完成：4 個來源模組 + 1 個新增回歸測試。');
console.log('備份已建立為各檔案旁的 .pre-v10.8.3-' + stamp + '.bak');
console.log('未修改 config.js、index.html、main.js、tactics.js 或其他模組；未執行 Git commit/push 或部署。');
console.log('下一步：node tests/v10-8-3-reasoning-smoke.js');
