古董局中局 v10.8.3｜四模組推理修補
================================

適用基底：CONFIG.VERSION = 10.8.2
修改範圍：
  js/bot/mind.js
  js/core/claims.js
  js/bot/speech.js
  js/bot/strategy.js
  新增 tests/v10-8-3-reasoning-smoke.js

安裝方式（Windows）
-------------------
1. 先備份你的專案資料夾，或至少保留上述四個原始模組。
2. 解壓縮本 ZIP 到一個獨立資料夾，不要直接解壓到專案根目錄。
3. 開啟 PowerShell，在解壓資料夾執行：

   node .\apply_v10_8_3_patch.js "C:\你的專案完整路徑"

4. 安裝成功後，切換到專案根目錄執行：

   node .\tests\v10-8-3-reasoning-smoke.js

安裝器會先確認 v10.8.2 版本、補丁檔案雜湊與必要標記，再建立四個原始模組的時間戳備份。遇到版本不符、測試檔衝突或部分安裝狀態會停止，不會猜測覆寫。

修正重點
--------
1. 只有私密查驗記錄 flipped === true，才建立老朝奉反轉時序池；flipped:false 的矛盾仍作為說謊／錯誤訊號，不再當成技能啟動證據。
2. 公開發言解析以可見原文為主。引用、轉述、歷史自稱與過期結構化 p 欄位不會再冒充當前發言者的證據。
3. 明確的第一人稱投票承諾會與實際落票對帳；「我建議大家投」「我可能投」「我不投」及引用台詞不會被當成自己的承諾。
4. 沒有明確承諾時保留合法棄票；承諾目標只在合法可用籌碼大於零時才強制至少投入一票，且不超過可用上限。
5. 發言歷史在舊回合缺少 voteResults.totals 時，改由原始 votes 重建票數，不會因缺欄位而崩潰。
6. 終局好人指認與顯示的嫌疑排行榜使用同一排序；弱證據候選會明示為待驗候選。方震私密查驗仍只供方震本人使用。

版本標籤說明
------------
依照本次限定的四個來源模組範圍，沒有修改 js/config.js 或 index.html。因此介面上的 CONFIG.VERSION 仍會顯示 10.8.2；v10.8.3 是這份四模組程式修補包的版本標籤。若要同步升級介面版本，需另開版本標籤變更，不包含在這次局部補丁內。

測試狀態（在上傳的專案副本中）
------------------------------
通過：
  tests/v10-8-3-reasoning-smoke.js（另連跑 20 次，均通過）
  tests/conversation-continuity-smoke.js
  tests/mind_gene_patch_smoke.js
  tests/player-reasoning-regression-smoke.js
  tests/public-speech-attribution-smoke.js
  tests/tactics-smoke.js
  tests/v10-8-public-roleplay-smoke.js
  tests/v10-8-strategic-info-smoke.js
  tests/abstain-policy-smoke.js
  tests/vote-policy-smoke.js

abstain-policy-smoke.js 與 vote-policy-smoke.js 的測試斷言都已印出通過；因測試環境保留事件迴圈 handle，使用短延遲 wrapper 結束程序後確認 exit 0。

既有基線限制：tests/ui-smoke.js 在乾淨 HEAD 基線也會因 js/main.js 的測試假 DOM 缺少 setAttribute 而失敗。該檔與 main.js 不在本補丁修改範圍內，故未擴大修正。

本補丁不會執行 Git commit、push 或任何部署。
